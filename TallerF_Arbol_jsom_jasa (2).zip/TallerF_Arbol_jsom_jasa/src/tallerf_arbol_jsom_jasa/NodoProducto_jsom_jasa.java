/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tallerf_arbol_jsom_jasa;

/**
 *
 * @author JAIRO OCAMPO Y JEFERSON SILGADO 
 */
public class NodoProducto_jsom_jasa {  
    int id;                     
    String nombre;              
    double precio;              

    NodoProducto_jsom_jasa izquierdo;   // Hijo izquierdo
    NodoProducto_jsom_jasa derecho;     // Hijo derecho

    public NodoProducto_jsom_jasa(int id, String nombre, double precio) {
        this.id = id;
        this.nombre = nombre;
        this.precio = precio;
        this.izquierdo = null;
        this.derecho = null;
        
    }
}
