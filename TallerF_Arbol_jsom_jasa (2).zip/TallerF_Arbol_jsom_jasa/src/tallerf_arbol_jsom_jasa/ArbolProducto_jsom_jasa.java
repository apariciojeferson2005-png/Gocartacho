/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tallerf_arbol_jsom_jasa;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import javax.swing.JTextArea;

/**
 *
 * @author JAIRO OCAMPO
 */
public class ArbolProducto_jsom_jasa {
    NodoProducto_jsom_jasa raiz;

    public ArbolProducto_jsom_jasa() {
        raiz = null;
    }

 // INSERTAR: 
    public void insertar(int id, String nombre, double precio) {
        NodoProducto_jsom_jasa nuevo = new NodoProducto_jsom_jasa(id, nombre, precio);

        if (raiz == null) {
            raiz = nuevo;
            return;
        }

        NodoProducto_jsom_jasa actual = raiz;
        NodoProducto_jsom_jasa padre = null;

        while (actual != null) {
            padre = actual;
            if (id < actual.id) {
                actual = actual.izquierdo;
            } else {
                actual = actual.derecho;
            }
        }

        if (id < padre.id) {
            padre.izquierdo = nuevo;
        } else {
            padre.derecho = nuevo;
        }
    }

    // BUSCAR:
    public NodoProducto_jsom_jasa buscar(int id) {
        NodoProducto_jsom_jasa actual = raiz;
        while (actual != null) {
            if (id == actual.id) return actual; // Encontrado
            if (id < actual.id) actual = actual.izquierdo;
            else actual = actual.derecho;
        }
        return null; // No encontrado
    }

    // ELIMINAR: 
    public void eliminar(int id) {
        raiz = eliminarRec(raiz, id);
    }
    private NodoProducto_jsom_jasa eliminarRec(NodoProducto_jsom_jasa nodo, int id) {
        if (nodo == null) return null;

        if (id < nodo.id) {
            nodo.izquierdo = eliminarRec(nodo.izquierdo, id);
        } else if (id > nodo.id) {
            nodo.derecho = eliminarRec(nodo.derecho, id);
        } else {
            
            if (nodo.izquierdo == null && nodo.derecho == null) return null;
           
            if (nodo.izquierdo == null) return nodo.derecho;
           
            if (nodo.derecho == null) return nodo.izquierdo;
            
            NodoProducto_jsom_jasa sucesor = minimoNodo(nodo.derecho);
            nodo.id = sucesor.id;
            nodo.nombre = sucesor.nombre;
            nodo.precio = sucesor.precio;
            nodo.derecho = eliminarRec(nodo.derecho, sucesor.id);
        }
        return nodo;
    }

    // RECORRIDO INORDEN 
    public void inOrden() {
        inOrdenRec(raiz);
    }
    private void inOrdenRec(NodoProducto_jsom_jasa nodo) {
        if (nodo != null) {
            inOrdenRec(nodo.izquierdo);
            System.out.println("ID: " + nodo.id + " | " + nodo.nombre + " | $" + nodo.precio);
            inOrdenRec(nodo.derecho);
        }
    }
    
    // MÍNIMO NODO POR ID (para eliminación en ABB)
private NodoProducto_jsom_jasa minimoNodo(NodoProducto_jsom_jasa nodo) {
    if (nodo == null) return null;
    NodoProducto_jsom_jasa actual = nodo;
    while (actual.izquierdo != null) {
        actual = actual.izquierdo;
    }
    return actual;
}

    // PRODUCTO CON PRECIO MÍNIMO
public NodoProducto_jsom_jasa minimoPrecio() {
    return minimoPrecioRec(raiz, null);
}

private NodoProducto_jsom_jasa minimoPrecioRec(NodoProducto_jsom_jasa nodo, NodoProducto_jsom_jasa actualMin) {
    if (nodo == null) return actualMin;
    if (actualMin == null || nodo.precio < actualMin.precio) actualMin = nodo;
    actualMin = minimoPrecioRec(nodo.izquierdo, actualMin);
    actualMin = minimoPrecioRec(nodo.derecho, actualMin);
    return actualMin;
}

// PRODUCTO CON PRECIO MÁXIMO (más caro)
public NodoProducto_jsom_jasa maximoPrecio() {
    return maximoPrecioRec(raiz, null);
}

private NodoProducto_jsom_jasa maximoPrecioRec(NodoProducto_jsom_jasa nodo, NodoProducto_jsom_jasa actualMax) {
    if (nodo == null) return actualMax;
    if (actualMax == null || nodo.precio > actualMax.precio) actualMax = nodo;
    actualMax = maximoPrecioRec(nodo.izquierdo, actualMax);
    actualMax = maximoPrecioRec(nodo.derecho, actualMax);
    return actualMax;
}

    // CONTAR NODOS
    public int contar() {
        return contarRec(raiz);
    }

    private int contarRec(NodoProducto_jsom_jasa nodo) {
        if (nodo == null) return 0;
        return 1 + contarRec(nodo.izquierdo) + contarRec(nodo.derecho);
    }

    // GUARDAR EN ARCHIVO (CSV simple)
    public void guardarEnArchivo(String ruta) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(ruta))) {
            guardarRec(raiz, bw);
        } catch (Exception e) {
        }
    }

    private void guardarRec(NodoProducto_jsom_jasa nodo, BufferedWriter bw) throws Exception {
        if (nodo != null) {
            bw.write(nodo.id + "," + nodo.nombre + "," + nodo.precio);
            bw.newLine();
            guardarRec(nodo.izquierdo, bw);
            guardarRec(nodo.derecho, bw);
        }
    }

    // CARGAR DESDE ARCHIVO
    public void cargarDesdeArchivo(String ruta) {
        try (BufferedReader br = new BufferedReader(new FileReader(ruta))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] p = linea.split(",");
                int id = Integer.parseInt(p[0]);
                String nombre = p[1];
                double precio = Double.parseDouble(p[2]);
                insertar(id, nombre, precio);
            }
        } catch (Exception e) {
        }
    }

    // INORDEN PARA MOSTRAR EN EL JTEXTAREA
    public void inOrdenTexto(NodoProducto_jsom_jasa nodo, JTextArea area) {
    if (nodo == null) return; // condición correcta
    inOrdenTexto(nodo.izquierdo, area);
    area.append("ID: " + nodo.id + " | " + nodo.nombre + " | " + nodo.precio + "\n");
    inOrdenTexto(nodo.derecho, area);
}
    // MÉTODO ENCAPSULADO: 
    public void mostrarEnArea(JTextArea area) {
        area.setText("");
        if (raiz == null) {
            area.setText("El árbol está vacío.");
        } else {
            inOrdenTexto(raiz, area);
        }
    }
    public NodoProducto_jsom_jasa getRaiz() {
        return raiz;
    }
}

