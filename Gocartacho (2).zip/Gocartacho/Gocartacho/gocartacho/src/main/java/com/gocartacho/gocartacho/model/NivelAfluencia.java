package com.gocartacho.gocartacho.model;

public enum NivelAfluencia {
    Bajo,
    Medio,
    Alto
}