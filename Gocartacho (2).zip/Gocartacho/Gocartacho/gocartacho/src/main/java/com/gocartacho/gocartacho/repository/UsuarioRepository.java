package com.gocartacho.gocartacho.repository;

import com.gocartacho.gocartacho.model.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;

@Repository
public interface UsuarioRepository extends JpaRepository<Usuario, Integer> {

    // Para el login y para verificar si un email ya existe.
    // Usamos Optional para manejar de forma segura si el usuario no se encuentra.
    Optional<Usuario> findByEmail(String email);
}