package com.gocartacho.gocartacho.model;

import jakarta.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "Ruta_Comercios")
public class RutaComercio implements Serializable {

    // 1. Usa la llave compuesta
    @EmbeddedId
    private RutaComercioId id;

    // 2. Mapea la relación con Ruta
    @ManyToOne(fetch = FetchType.LAZY)
    @MapsId("rutaId") // Mapea el campo 'rutaId' de nuestra EmbeddedId
    @JoinColumn(name = "ruta_id")
    private Ruta ruta;

    // 3. Mapea la relación con Comercio
    @ManyToOne(fetch = FetchType.LAZY)
    @MapsId("comercioId") // Mapea el campo 'comercioId' de nuestra EmbeddedId
    @JoinColumn(name = "comercio_id")
    private Comercio comercio;

    // 4. El campo extra de la tabla de unión
    @Column(name = "orden", nullable = false)
    private Integer orden;

    public RutaComercioId getId() {
        return id;
    }

    public void setId(RutaComercioId id) {
        this.id = id;
    }

    public Ruta getRuta() {
        return ruta;
    }

    public void setRuta(Ruta ruta) {
        this.ruta = ruta;
    }

    public Comercio getComercio() {
        return comercio;
    }

    public void setComercio(Comercio comercio) {
        this.comercio = comercio;
    }

    public Integer getOrden() {
        return orden;
    }

    public void setOrden(Integer orden) {
        this.orden = orden;
    }
}