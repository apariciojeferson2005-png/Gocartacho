package com.gocartacho.gocartacho.controller;

import com.gocartacho.gocartacho.model.Comercio;
import com.gocartacho.gocartacho.model.TipoNegocio;
import com.gocartacho.gocartacho.service.ComercioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/comercios")
public class ComercioController {

    @Autowired
    private ComercioService comercioService;

    /**
     * Endpoint para obtener comercios por zona, con filtro opcional por tipo.
     * URL: GET /api/v1/comercios/zona/1
     * URL: GET /api/v1/comercios/zona/1?tipo=Restaurante
     */
    @GetMapping("/zona/{zonaId}")
    public ResponseEntity<List<Comercio>> obtenerComerciosPorZona(
            @PathVariable Integer zonaId,
            @RequestParam(required = false) TipoNegocio tipo) {
        
        List<Comercio> comercios;
        if (tipo != null) {
            comercios = comercioService.obtenerComerciosPorZonaYTipo(zonaId, tipo);
        } else {
            comercios = comercioService.obtenerComerciosPorZona(zonaId);
        }
        return ResponseEntity.ok(comercios);
    }
    
    /**
     * Endpoint para obtener el detalle de un solo comercio por su ID.
     * URL: GET /api/v1/comercios/42
     */
    @GetMapping("/{id}")
    public ResponseEntity<Comercio> obtenerComercioPorId(@PathVariable Integer id) {
        Comercio comercio = comercioService.obtenerComercioPorId(id);
        if (comercio != null) {
            return ResponseEntity.ok(comercio);
        } else {
            return ResponseEntity.notFound().build(); // Devuelve 404 Not Found
        }
    }
}