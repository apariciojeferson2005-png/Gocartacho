package com.gocartacho.gocartacho.model;

import jakarta.persistence.*;
import java.io.Serializable;
import java.time.LocalDateTime;

@Entity
@Table(name = "Resenas")
public class Resena implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "resena_id")
    private Integer resenaId;

    @Column(name = "calificacion", nullable = false)
    private Integer calificacion; // (Ej: 1-5)

    @Column(name = "comentario", columnDefinition = "TEXT")
    private String comentario;

    @Column(name = "fecha", updatable = false)
    private LocalDateTime fecha;

    // --- Relación con Usuario ---
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "usuario_id", nullable = false) // Una reseña DEBE tener un usuario
    private Usuario usuario;

    // --- Relación con Comercio ---
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "comercio_id", nullable = false) // Una reseña DEBE ser sobre un comercio
    private Comercio comercio;

    // --- Método para asignar fecha antes de guardar ---
    @PrePersist
    protected void onCreate() {
        this.fecha = LocalDateTime.now();
    }

    public void setCalificacion(Integer calificacion) {
        this.calificacion = calificacion;
    }

    public String getComentario() {
        return comentario;
    }

    public void setComentario(String comentario) {
        this.comentario = comentario;
    }

    public LocalDateTime getFecha() {
        return fecha;
    }

    public void setFecha(LocalDateTime fecha) {
        this.fecha = fecha;
    }

    public Integer getResenaId() {
        return resenaId;
    }

    public void setResenaId(Integer resenaId) {
        this.resenaId = resenaId;
    }

    public Integer getCalificacion() {
        return calificacion;
    }

    // ... (restantes)
    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public Comercio getComercio() {
        return comercio;
    }

    public void setComercio(Comercio comercio) {
        this.comercio = comercio;
    }
}