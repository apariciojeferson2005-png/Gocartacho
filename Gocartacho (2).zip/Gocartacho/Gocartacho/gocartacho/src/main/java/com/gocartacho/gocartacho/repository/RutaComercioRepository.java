package com.gocartacho.gocartacho.repository;

import com.gocartacho.gocartacho.model.Ruta;
import com.gocartacho.gocartacho.model.RutaComercio;
import com.gocartacho.gocartacho.model.RutaComercioId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface RutaComercioRepository extends JpaRepository<RutaComercio, RutaComercioId> {

    // Para la función: "Traer todos los comercios de ESTA ruta"
    // Los ordenamos por el campo 'orden' para que aparezcan en la secuencia correcta.
    List<RutaComercio> findByRutaOrderByOrdenAsc(Ruta ruta);
}