package com.gocartacho.gocartacho.service;

import com.gocartacho.gocartacho.model.Zona;
import java.util.List;

public interface ZonaService {
    
    List<Zona> obtenerTodasLasZonas();
    
    Zona obtenerZonaPorId(Integer id);
    
    Zona guardarZona(Zona zona);
    
    void eliminarZona(Integer id);
}