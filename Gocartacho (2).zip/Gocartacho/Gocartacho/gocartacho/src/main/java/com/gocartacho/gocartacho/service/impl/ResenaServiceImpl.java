package com.gocartacho.gocartacho.service.impl;

import com.gocartacho.gocartacho.dto.ResenaRequest;
import com.gocartacho.gocartacho.model.Comercio;
import com.gocartacho.gocartacho.model.Resena;
import com.gocartacho.gocartacho.model.Usuario;
import com.gocartacho.gocartacho.repository.ComercioRepository;
import com.gocartacho.gocartacho.repository.ResenaRepository;
import com.gocartacho.gocartacho.repository.UsuarioRepository;
import com.gocartacho.gocartacho.service.ResenaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;

@Service
public class ResenaServiceImpl implements ResenaService {

    @Autowired
    private ResenaRepository resenaRepository;

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private ComercioRepository comercioRepository;

    @Override
    public Resena guardarResena(ResenaRequest request) throws Exception {
        // Lógica de negocio: Validar que el usuario y el comercio existan
        Usuario usuario = usuarioRepository.findById(request.getUsuarioId())
                .orElseThrow(() -> new Exception("Usuario no encontrado con ID: " + request.getUsuarioId()));
        
        Comercio comercio = comercioRepository.findById(request.getComercioId())
                .orElseThrow(() -> new Exception("Comercio no encontrado con ID: " + request.getComercioId()));

        // Crear la entidad Resena a partir del DTO
        Resena nuevaResena = new Resena();
        nuevaResena.setCalificacion(request.getCalificacion());
        nuevaResena.setComentario(request.getComentario());
        nuevaResena.setUsuario(usuario);
        nuevaResena.setComercio(comercio);
        nuevaResena.setFecha(LocalDateTime.now()); // El @PrePersist también lo haría

        return resenaRepository.save(nuevaResena);
    }

    @Override
    public List<Resena> obtenerResenasPorComercio(Integer comercioId) {
        return comercioRepository.findById(comercioId)
                .map(resenaRepository::findByComercioOrderByFechaDesc)
                .orElse(Collections.emptyList());
    }
}