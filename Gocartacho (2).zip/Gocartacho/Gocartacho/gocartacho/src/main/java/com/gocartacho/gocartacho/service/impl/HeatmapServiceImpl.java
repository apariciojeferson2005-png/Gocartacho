package com.gocartacho.gocartacho.service.impl;

import com.gocartacho.gocartacho.dto.HeatmapPointDTO;

import com.gocartacho.gocartacho.model.*;

import com.gocartacho.gocartacho.repository.AfluenciaHistoricaRepository;

import com.gocartacho.gocartacho.repository.PuntoCalorRepository;

import com.gocartacho.gocartacho.repository.ZonaRepository;

import com.gocartacho.gocartacho.service.HeatmapService;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;



import java.time.LocalDateTime;

import java.util.ArrayList;

import java.util.List;

import java.util.Optional;



@Service

public class HeatmapServiceImpl implements HeatmapService {



    @Autowired

    private PuntoCalorRepository puntoCalorRepository;



    @Autowired

    private AfluenciaHistoricaRepository afluenciaHistoricaRepository;



    @Autowired

    private ZonaRepository zonaRepository;



    @Override

    public void guardarPuntoCalor(PuntoCalor puntoCalor) {

        // Añade la marca de tiempo antes de guardar

        puntoCalor.setTimestamp(LocalDateTime.now());

        puntoCalorRepository.save(puntoCalor);

    }



    @Override

    public List<HeatmapPointDTO> obtenerPuntosCalorTiempoReal() {

        List<HeatmapPointDTO> points = new ArrayList<>();



        // --- DATOS DE MUESTRA PARA VISUALIZACIÓN ---

        // Zona amurallada y Getsemaní (intensidad alta)

        points.add(new HeatmapPointDTO(10.4235, -75.5509, 0.9)); // Cerca de la Torre del Reloj

        points.add(new HeatmapPointDTO(10.4248, -75.5523, 0.7)); // Plaza de los Coches

        points.add(new HeatmapPointDTO(10.4215, -75.5518, 0.8)); // Getsemaní, Plaza de la Trinidad

        points.add(new HeatmapPointDTO(10.4200, -75.5530, 0.6)); // Calle del Arsenal

        points.add(new HeatmapPointDTO(10.4270, -75.5495, 0.5)); // Cerca de Las Bóvedas



        // Bocagrande (intensidad media-alta)

        points.add(new HeatmapPointDTO(10.3985, -75.5602, 0.85)); // Avenida San Martín

        points.add(new HeatmapPointDTO(10.3950, -75.5630, 0.7)); // Playa de Bocagrande



        // Simular más puntos aleatorios para dar densidad

        points.add(new HeatmapPointDTO(10.4240, -75.5515, 0.4));

        points.add(new HeatmapPointDTO(10.4222, -75.5525, 0.5));

        points.add(new HeatmapPointDTO(10.3970, -75.5610, 0.6));

        

        return points;

    }



    @Override

    public NivelAfluencia obtenerAfluenciaHistorica(Integer zonaId, DiaSemana dia, int hora) {

        Optional<Zona> zona = zonaRepository.findById(zonaId);



        if (zona.isPresent()) {

            Optional<AfluenciaHistorica> historico = afluenciaHistoricaRepository

                    .findByZonaAndDiaSemanaAndHora(zona.get(), dia, hora);



            return historico.map(AfluenciaHistorica::getNivelPromedio).orElse(NivelAfluencia.Bajo);

        }



        return NivelAfluencia.Bajo; // Devuelve Bajo si la zona no existe

    }

}
