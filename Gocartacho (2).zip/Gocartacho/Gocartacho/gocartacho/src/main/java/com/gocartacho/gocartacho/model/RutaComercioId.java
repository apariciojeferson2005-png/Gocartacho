package com.gocartacho.gocartacho.model;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import java.io.Serializable;
import java.util.Objects;

@Embeddable // Indica que esta clase se "incrusta" en otra entidad
public class RutaComercioId implements Serializable {

    @Column(name = "ruta_id")
    private Integer rutaId;

    @Column(name = "comercio_id")
    private Integer comercioId;

    // Constructor vacío
    public RutaComercioId() {}

    // Constructor con campos
    public RutaComercioId(Integer rutaId, Integer comercioId) {
        this.rutaId = rutaId;
        this.comercioId = comercioId;
    }

    public Integer getRutaId() {
        return rutaId;
    }

    public void setRutaId(Integer rutaId) {
        this.rutaId = rutaId;
    }

    public Integer getComercioId() {
        return comercioId;
    }

    public void setComercioId(Integer comercioId) {
        this.comercioId = comercioId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        RutaComercioId that = (RutaComercioId) o;
        return Objects.equals(rutaId, that.rutaId) &&
               Objects.equals(comercioId, that.comercioId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(rutaId, comercioId);
    }
}