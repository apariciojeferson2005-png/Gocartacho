package com.gocartacho.gocartacho.repository;

import com.gocartacho.gocartacho.model.Comercio;
import com.gocartacho.gocartacho.model.TipoNegocio;
import com.gocartacho.gocartacho.model.Zona;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface ComercioRepository extends JpaRepository<Comercio, Integer> {

    // Spring Data JPA crea esta consulta automáticamente basándose en el nombre del método.
    
    // Para la función: "Mostrar todos los comercios de ESTA zona"
    List<Comercio> findByZona(Zona zona);

    // Para la función: "Filtrar por tipo de negocio"
    List<Comercio> findByTipoNegocio(TipoNegocio tipoNegocio);
    
    // Para el filtro combinado: "Mostrar restaurantes en ESTA zona"
    List<Comercio> findByZonaAndTipoNegocio(Zona zona, TipoNegocio tipoNegocio);
}