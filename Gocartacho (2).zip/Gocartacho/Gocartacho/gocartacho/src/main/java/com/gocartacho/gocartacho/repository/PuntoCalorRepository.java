package com.gocartacho.gocartacho.repository;

import com.gocartacho.gocartacho.model.PuntoCalor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface PuntoCalorRepository extends JpaRepository<PuntoCalor, Long> {

    // ¡EL MÉTODO MÁS IMPORTANTE PARA EL MAPA DE CALOR!
    // Para la función: "Traer todos los pings de los últimos 10 minutos"
    List<PuntoCalor> findByTimestampAfter(LocalDateTime timestamp);
}