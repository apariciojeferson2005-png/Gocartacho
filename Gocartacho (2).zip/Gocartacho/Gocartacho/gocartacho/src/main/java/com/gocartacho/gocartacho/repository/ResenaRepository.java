package com.gocartacho.gocartacho.repository;

import com.gocartacho.gocartacho.model.Comercio;
import com.gocartacho.gocartacho.model.Resena;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface ResenaRepository extends JpaRepository<Resena, Integer> {

    // Para la función: "Mostrar todas las reseñas de ESTE comercio"
    // Las ordenamos por fecha descendente para mostrar las más nuevas primero.
    List<Resena> findByComercioOrderByFechaDesc(Comercio comercio);
}