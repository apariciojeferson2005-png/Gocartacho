package com.gocartacho.gocartacho.model;

import jakarta.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "Rutas")
public class Ruta implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ruta_id")
    private Integer rutaId;

    @Column(name = "nombre_ruta", nullable = false, length = 255)
    private String nombreRuta;

    @Column(name = "descripcion", columnDefinition = "TEXT")
    private String descripcion;

    public Integer getRutaId() {
        return rutaId;
    }

    public void setRutaId(Integer rutaId) {
        this.rutaId = rutaId;
    }

    public String getNombreRuta() {
        return nombreRuta;
    }

    public void setNombreRuta(String nombreRuta) {
        this.nombreRuta = nombreRuta;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
}