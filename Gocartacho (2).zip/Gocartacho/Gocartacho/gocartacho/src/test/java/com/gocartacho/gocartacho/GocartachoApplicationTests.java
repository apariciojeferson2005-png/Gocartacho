package com.gocartacho.gocartacho;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GocartachoApplicationTests {

	@Test
	void contextLoads() {
	}

}
